#!/bin/bash


echo "Установка модуля Payment module Morune ..."

echo "Проверка наличия unzip..."
unzippath=$(which unzip)
if [ -z $unzippath ]; then
	echo -e "\e[31mUnzip отсутствует!\e[0m"
	exit
fi
echo "OK!"

plagindir="/usr/local/mgr5/morune-temp"

mkdir $plagindir
unzip "morune.zip" -d $plagindir >/dev/null

bmpath="/usr/local/mgr5/"

for dir in $plagindir/*; do
	filename=$(basename $dir)
  cp -rf $dir $bmpath
  if [ $? -ne 0 ]; then
    echo -e "\e[31mВозникли проблемы при копировании файлов!\e[0m"
    rm -R $plagindir
    exit
  else
    find $bmpath$filename -type f -name "*.php" -exec chmod 755 {} \;
  fi
done

rm -R $plagindir

echo "Перезагрузка биллинга..."
/usr/local/mgr5/sbin/mgrctl exit -m billmgr
sleep 3

echo -e "\e[32mМодуль успешно установлен!\e[0m"